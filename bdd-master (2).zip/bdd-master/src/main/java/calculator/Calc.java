package calculator;
public class Calc {
    public int sum(int a, int b) {

        return a + b;
    }
}